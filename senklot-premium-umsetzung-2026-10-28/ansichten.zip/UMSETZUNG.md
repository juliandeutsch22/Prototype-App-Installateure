# Premium-Feinschliff · 28. Oktober 2026

Grundlage ist der freigegebene [Entwurf 02](https://github.com/juliandeutsch22/Prototype-App-Installateure/blob/2ca7e90aea896024a374679cad3d8b38be479007/senklot-premium-entwurf-02-2026-10-28/README.md), auf App-Stand `7601e378`. Die vorhandenen Seiten, Rollen, Fachabläufe und mobilen Reiter bleiben erhalten. App-Icon, Datenbankschema, RPC-Signaturen und Zahlenberechnung sind unverändert. Es kommt keine Bibliothek hinzu.

## Gemeinsames Verhalten

- `lot-feinschliff.css`: 100 ms Druck-/Farbantwort, 160 ms Status und Menü, 200 ms Overlay öffnen, 140 ms schließen. Keine Feder-/Skalierungsanimation der Buttons und keine animierte Tabellengeometrie. Bestehender Seitenwechsel bleibt bei 160 ms.
- `Button`: laufender Zustand ist per `aria-busy` erkennbar. Der zuvor gemessene Platz wird beim laufenden/bestätigten Zustand reserviert und auf die verfügbare Breite begrenzt. `gespeichert` wird vom Aufrufer nur nach bestätigtem Schreiben gesetzt. Bestehende Größen und Varianten bleiben erhalten.
- `BottomSheet` und `ConfirmDialog`: gemeinsame Ein-/Ausblendung. Solange das schließende Overlay montiert ist, bleiben Fokusfalle und Hintergrundsperre erhalten. Erneutes Öffnen bricht den Abbau ab. Bei reduziertem Bewegungswunsch entfällt die Verzögerung. Ziehbewegung und vorhandene Transform-Regeln des Blatts bleiben getrennt von der Deckkraftanimation. Ein am Tablet ausgeblendetes mobiles Mehr-Blatt sperrt weder Fokus noch Scrollen.
- Menüs, Reiter und weitere Angaben verwenden kurze Rückmeldungen. Der bestehende Fokus auf dunkler Navigation bleibt weiß; Inhaltsflächen verwenden das passende helle/dunkle Petrol.
- Die 29 bestehenden Icons bleiben dieselbe Familie. Zwei kleine statische Lot-Zeichnungen erscheinen nur beim ersten Bestand von Baustellen/Angeboten; weder bei Suche/Filter noch bei einem Ladefehler oder während bereits ein neues Formular offen ist. Die vorhandene Hauptaktion behält auch beim Erstbestand ihre gewohnte Position; die Illustration bekommt keinen doppelten Hauptknopf. Keine Haptik-Anbindung oder Vibration.

## Verlässliches Ergebnis einer Aktion

| Bereich | Verhalten nach der Änderung |
|---|---|
| Rechnung / PDF | Bestätigtes Ausstellen bleibt bestätigt. Scheitert anschließend die PDF-Ausgabe, bleibt eine konkrete Meldung mit Rechnungsnummer und reiner PDF-Wiederholung stehen. Während der ausstehenden Ausstellungsbestätigung sind Eingaben, Verwerfen und Schließen gesperrt. Die Vorschau zur Erstellung wird nach bestätigtem Schreiben geschlossen; die PDF-Wiederholung ruft das Ausstellen nicht erneut auf. |
| Unterbrochene Rechnungsantwort | Transportfehler oder eine ungültige Antwort werden vom bestätigten SQL-Fehler unterschieden. Der Ausgang bleibt ausdrücklich unklar. Die Erstellung ist aus dieser Ansicht gesperrt; die Liste kann zur manuellen Prüfung geöffnet werden. Kein automatischer zweiter Schreibaufruf und kein behaupteter sicherer Statusabgleich. |
| Firmendaten | Änderungen werden über alle vorhandenen Felder einschließlich Logo/Farben verglichen. Interne Links und Neuladen warnen bei offenen Änderungen. Doppelte Übermittlung ist synchron gesperrt. Während des Schreibens ergänzte Eingaben bleiben offen. Verwerfen stellt den zuletzt bestätigten Stand wieder her. |
| Firmendaten / Nachladen | Ein bestätigtes Schreiben bleibt gespeichert, wenn danach nur das Nachladen fehlschlägt. „Anzeige erneut laden“ wiederholt ausschließlich das Lesen. Nebenschaltflächen im Formular sind ausdrücklich `type="button"`. |
| Feldfehler | UID-/IBAN-/BIC-Hinweise sind mit dem jeweiligen Feld über `aria-describedby` verbunden; vorhandene fachliche Prüfungen gelten unverändert. |
| Katalog | Ergebnisse gehören zu genau einem Suchlauf und Betrieb. Alte Treffer verschwinden bereits beim Eingeben einer neuen Suche. Überholte Antworten sind nicht auswählbar. Laden, Fehler/Wiederholung und keine Treffer/Zurücksetzen bleiben getrennt; übernommene Positionen bleiben erhalten. |
| Nachsendefehler | Endgültige Ablehnung bleibt innerhalb der Sitzung bis „Gelesen“ sichtbar. Es gibt keine automatische Neubuchung. Die allgemeine Offline-Zeile verspricht keine Ablage für ununterstützte Schreibwege. |
| Kurze Meldungen | Restzeit pausiert unabhängig bei Fokus und Maus-Hover. Der Timer verwendet eine monotone Uhr. Die Meldungsfläche lässt weiterhin Klicks zur Seite durch; Hover wird geometrisch beobachtet. |

## Prüfungen

Gezielte Komponentenprüfungen decken bestätigtes Schreiben/PDF-Fehler, Transportabbruch, doppelte Übermittlung, Eingaben während des Schreibens, Nachladefehler, Verwerfen, Feldzuordnung, überholte Suche, Wiederholung sowie dauerhafte und pausierte Meldungen ab. Overlay-Prüfungen prüfen unterbrochenes Schließen, erneutes Öffnen und Freigabe der Hintergrundsperre.

`tests/links/premium.spec.ts` prüft auf echten Vorschau-Komponenten drei Breiten mit und ohne reduzierte Bewegung, gestapelte Dialoge, Tab/Escape, erhaltene Firmeneingaben, axe, Überlauf, schnelle Blattfolgen, Ziehen und Maus-Hover bei durchlässiger Meldungsfläche. Chromium und WebKit sind konfiguriert; die WebKit-Konfiguration emuliert Touch und überspringt deshalb ausschließlich die Maus-Hover-Prüfung. Die bestehende CI installiert deren Systemabhängigkeiten und führt außerdem die fachlichen Durchklick-Wege mit lokalem Supabase aus.

Die breite Ansichtenprüfung umfasst 69 Seiten-/Rollen-/Reiter-Kontexte in 320, 390, 834, 1194 und 1440 px sowie ausgewählte dunkle Ansichten. Sie ergänzt die Funktionsprüfungen; ein Bild allein beweist keine fachliche Vollständigkeit. Aktueller CI-Stand und Release-Nachweis gehören zum Pull Request, nicht zu einer pauschalen Zusicherung in diesem Dokument.

Vor dem Release: `npm run typecheck`, `npm run lint`, `npm test`, `npm run build`, `npm run pruefen:links`, reguläre Durchklick-/Inhaltsregel-Prüfung und die verpflichtenden Repository-Checks. Fehlschläge werden untersucht, nicht durch automatisches Wiederholen verdeckt.

## Bewusste Grenzen

1. Der bestehende Schutz für ungespeicherte Eingaben fängt interne Links und Browser-Neuladen ab. Er blockiert mit dem vorhandenen `BrowserRouter` die Zurück-Taste des Browsers nicht. Eine vollständige Navigationssperre ist keine Leistung dieser Änderung; der Router wird nicht nebenbei ersetzt.
2. Ein sicherer automatischer Abgleich einer unterbrochenen Rechnungserstellung benötigt eine nachweisbare Zuordnung zum konkreten Erstellungsversuch. Ein Listenvergleich nach Name/Betrag genügt nicht. Der Design-Prompt verbietet Datenbankstrukturänderungen; deshalb wird hier kein solcher Mechanismus behauptet oder durch eine riskante Wiederholung ersetzt. Nach einem Neuladen besteht die serverseitige Ungewissheit weiterhin und muss fachlich geklärt werden.
3. Bestätigte Nachsendewarnungen werden nicht über einen App-Neustart hinweg als dauerhaftes, kontogebundenes Fehlerarchiv gespeichert.
4. Browser-Emulation ersetzt keinen physischen iPhone-/Android-Test mit Bildschirmtastatur, Bedienungshilfen und älterer Hardware. WebKit in CI ist ebenfalls kein Hardwaretest. Es wird keine native iOS-Haptik zugesagt.
