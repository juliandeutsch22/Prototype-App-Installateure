# Aufnahmen wiederholen

Die Skripte benötigen Playwright aus dem App-Repository. Vor dem Ausführen ins `node_modules/` dieses Checkouts kopieren, damit Node das installierte Paket findet. `npm run vorschau` muss auf Port 5199 laufen. `SENKLOT_BILDER` bestimmt den Ausgabeordner, `CHROMIUM_PFAD` den Browser; Standard sind die Pfade dieser Cloud-Umgebung.

1. `demo-daten.js` im Ausgabeordner bereithalten.
2. `aufnahmen.mjs` ausführen. Das ersetzt ausschließlich `screens/` und `vorschau/` des angegebenen Ausgabeordners und schreibt das Manifest neu. Es verändert keinen App-Code und keine Datenbank.
3. Für die Mockups den Ausgabeordner lokal auf Port 7199 bereitstellen: `python -m http.server 7199 --bind 127.0.0.1 --directory <Ausgabeordner>`.
4. `mockups-export.mjs` ausführen. Es fotografiert die editierbare HTML-Vorlage.
5. `python <Ausgabeordner>/galerie-erzeugen.py` schreibt die Galerie.

`ergaenzen.mjs` dokumentiert den zusätzlichen Aufnahmegang, aus dem u. a. Anmeldung und Unterschriftenansicht stammen. Das vollständige `aufnahmen.mjs` enthält diese Motive inzwischen ebenfalls. Die Vorlagen und Demodaten müssen mit dem App-Stand übereinstimmen; die Vorschau ist ein Werkzeug für Bilder, kein Ersatz für echte Funktionsprüfungen.
