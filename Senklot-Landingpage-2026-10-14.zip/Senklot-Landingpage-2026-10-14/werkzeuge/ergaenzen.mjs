import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';
const OUT=(process.env.SENKLOT_BILDER || '/workspace/Senklot-Landingpage-2026-10-14');
for(const d of ['screens/desktop','screens/handy','screens/tablet','screens/dunkel','vorschau','mockups'])fs.mkdirSync(path.join(OUT,d),{recursive:true});
const G='Geschäftsführung', M='Mitarbeiter', A='Administrator';
const routes=[
['01-start','Startseite Büro','/',G],['02-start-monteur','Startseite Monteur','/',M],
['03-baustellen','Baustellen','/admin-projects',G],['04-baustellenakte','Baustellenakte','/admin-projects/p1',G],
['05-planung-woche','Einsatzplanung Woche','/assignments/woche',G],['06-planung-tag','Einsatzplanung Tag','/assignments/tag',G],
['07-handwerksscheine','Handwerksscheine','/worksheets',G],['08-schein-erfassen','Handwerksschein erfassen','/worksheet?entwurf=s1',M],
['09-angebote','Angebote','/quotes',G],['10-angebotsakte','Angebotsakte','/quotes/q1',G],
['11-kunden','Kunden','/customers',G],['12-kundenakte','Kundenakte','/customers/k1',G],
['13-wartungen','Wartungen','/wartungen',G],['14-rechnungen','Rechnungen','/invoices',G],
['15-nachkalkulation','Nachkalkulation','/costing',G],['16-zeiterfassung','Zeiterfassung','/time',M],
['17-urlaub','Urlaub und Freistellungen','/vacations',G],['18-mitarbeiteruebersicht','Mitarbeiterübersicht','/accounting',G],
['19-benutzerverwaltung','Benutzerverwaltung','/user-mgmt',G],['20-mitarbeiterakte','Mitarbeiterakte','/user-mgmt/u1',G],
['21-material','Material anfordern','/material',M],['22-anforderungen','Materialanforderungen','/anforderungen',G],
['23-lager','Lager','/lager',G],['24-meine-baustellen','Meine Baustellen','/my-projects',M],
['25-meine-einsaetze','Meine Einsätze','/my-schedule/mein',M],['26-team-woche','Teamwoche','/my-schedule/team',M],
['27-einstellungen','Einstellungen Übersicht','/settings/uebersicht',G],['28-meldungen','Meldungen und eigenes Konto','/settings/meldungen',G],
['29-firmendaten','Firmendaten','/settings/firma',G],['30-saetze','Sätze','/settings/saetze',G],
['31-rechnungseinstellungen','Rechnungseinstellungen','/settings/rechnung',G],['32-nummern','Nummernkreise','/settings/nummern',G],
['33-personal','Personaleinstellungen','/settings/personal',G],['34-konten','Kontenrahmen','/settings/konten',G],
['35-support','Supportzugang','/settings/support',G],['36-module','Module','/settings/module',A],
['37-sicherung','Datensicherung und Archive','/settings/sicherung',G],
['38-impressum','Impressum (Entwurf)','/impressum',A],['39-datenschutz','Datenschutz (Entwurf)','/datenschutz',A],
];
const fixture=fs.readFileSync(path.join(OUT,'demo-daten.js'),'utf8');
const browser=await chromium.launch({executablePath:(process.env.CHROMIUM_PFAD || '/usr/bin/chromium'),args:['--no-sandbox','--lang=de'],env:{...process.env,LANG:'de_AT.UTF-8',LC_ALL:'de_AT.UTF-8',LANGUAGE:'de'}});
const manifest=JSON.parse(fs.readFileSync(path.join(OUT,'manifest.json'),'utf8')).screens;
const failures=[];
const configs={desktop:{width:1440,height:1000},handy:{width:390,height:844},tablet:{width:834,height:1112},dunkel:{width:1440,height:1000}};
const tablets=new Set(['01-start','04-baustellenakte','05-planung-woche','08-schein-erfassen','10-angebotsakte','12-kundenakte','14-rechnungen','16-zeiterfassung','18-mitarbeiteruebersicht','21-material','23-lager','26-team-woche']);
const darks=new Set(['01-start','05-planung-woche','10-angebotsakte','14-rechnungen','16-zeiterfassung','23-lager']);
async function capture(row,format,action){
const [id,title,route,role]=row;
const viewport=configs[format];
const context=await browser.newContext({viewport,deviceScaleFactor:2,locale:'de-AT',timezoneId:'Europe/Vienna',isMobile:format==='handy',hasTouch:format==='handy'||format==='tablet',colorScheme:'light'});
await context.addInitScript(({dark})=>{localStorage.setItem('senklot.darstellung',dark?'dunkel':'hell');},{dark:format==='dunkel'});
// Nur die Vorschau-Demodaten erhalten neutrale Namen und reservierte Adressen.
await context.route('**/tools/vorschau/daten.ts*',async r=>{const response=await r.fetch();let body=await response.text();body=body.split('//# sourceMappingURL')[0]+'\n'+fixture;body=body.replaceAll('Perl Installationen GmbH','Mustertechnik Installationen GmbH').replaceAll('@perl.at','@mustertechnik.example').replaceAll('www.perl.at','www.mustertechnik.example').replaceAll('office@hv-mayrhofer.at','office@hausverwaltung.example');await r.fulfill({response,body});});
await context.route('**/tools/vorschau/db/**',async r=>{
const url=new URL(r.request().url());const name=url.pathname.split('/').pop();
if(!['timeEntries.ts','assignments.ts','laeufe.ts','basiszins.ts','konten.ts'].includes(name))return r.continue();
const response=await r.fetch();let body=(await response.text()).split('//# sourceMappingURL')[0];
if(name==='timeEntries.ts'){
body=body.replace('export const listOwnEntriesSince = () => A(D.zeiten);',"export const listOwnEntriesSince = (_c,u,from) => A(D.zeiten.filter(x=>x.userId===u && x.date>=from));");
body=body.replace('export const listOwnEntriesInRange = () => A(D.zeiten);',"export const listOwnEntriesInRange = (_c,u,from,to) => A(D.zeiten.filter(x=>x.userId===u && x.date>=from && x.date<=to));");
body=body.replace('export const subscribeOwnEntriesInRange = SUB(D.zeiten);',"export const subscribeOwnEntriesInRange = (_c,u,from,to,cb) => {setTimeout(()=>cb(D.zeiten.filter(x=>x.userId===u && x.date>=from && x.date<=to)),0);return ()=>{};};");
}
if(name==='assignments.ts'){
body=body.replace('export const listAssignmentsForDate = () => A(D.einsaetze);',"export const listAssignmentsForDate = (_c,date) => A(D.einsaetze.filter(x=>x.date===date));");
body=body.replace('export const listUpcomingAssignments = () => A(D.einsaetze);',"export const listUpcomingAssignments = (_c,u,from) => A(D.einsaetze.filter(x=>x.userId===u && x.date>=from));");
}
if(name==='laeufe.ts')body=body.replace('export const ladeLauf = () => A(null);',"export const ladeLauf = (companyId,art) => A({companyId,art,zuletztErfolg:Date.now()-8*3600000,zuletztVersuch:Date.now()-8*3600000,erfolg:true,zielExtern:true,kennzahl:1248,kennzahlEinheit:'Zeilen'});");
if(name==='basiszins.ts')body=body.replace('export const listBasiszinssaetze = () => A([]);',"export const listBasiszinssaetze = () => A([{ab:'2026-07-01',satz:1.53}]);");
if(name==='konten.ts')body=body.replace('export const buchungskonten = () => A([]);',"export const buchungskonten = () => A([{id:'bk1',companyId:'perl',zweck:'erloes',ustSatz:0.2,konto:'4000',steuercode:'1'},{id:'bk2',companyId:'perl',zweck:'bank',konto:'2800'}]);");
await r.fulfill({response,body});
});
if(route==='/login')await context.route('**/tools/vorschau/AuthStub.tsx*',async r=>{const response=await r.fetch();const body=(await response.text()).replace(/user: \{[^}]+\},/, 'user: null,');await r.fulfill({response,body});});
const page=await context.newPage();page.setDefaultTimeout(7000);const errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
await page.goto('http://127.0.0.1:5199/tools/vorschau/?'+new URLSearchParams({pfad:route,rolle:role}),{waitUntil:'networkidle',timeout:45000});
await page.locator('h1').first().waitFor({timeout:15000});
await page.evaluate(()=>document.fonts.ready);await page.waitForTimeout(250);
if(action){await action(page);await page.waitForTimeout(300);}
const text=await page.locator('body').innerText();
if(errors.length||/Etwas ist schiefgelaufen|Diese Seite konnte nicht geladen werden/.test(text))throw new Error(errors.join('; ')||'Fehlergrenze sichtbar');
const screenshot=`screens/${format}/${id}.png`;
await page.screenshot({path:path.join(OUT,screenshot),animations:'disabled'});
const preview=`vorschau/${format}-${id}.jpg`;
await page.screenshot({path:path.join(OUT,preview),type:'jpeg',quality:78,scale:'css',animations:'disabled'});
const sizes=await page.evaluate(()=>({width:innerWidth,height:innerHeight,scrollWidth:document.documentElement.scrollWidth,scrollHeight:document.documentElement.scrollHeight}));
let full=null;
if(sizes.scrollHeight>viewport.height+100){full=`screens/${format}/${id}-gesamt.png`;await page.screenshot({path:path.join(OUT,full),fullPage:true,animations:'disabled'});}
const headings=await page.locator('h1,h2').allTextContents();
for(let i=manifest.length-1;i>=0;i--)if(manifest[i].id===id&&manifest[i].format===format)manifest.splice(i,1);
manifest.push({id,title,route,role,format,viewport,dpr:2,screenshot,full,preview,headings,sizes,errors});
console.log(`OK ${format} ${id}: ${headings[0]}`);
}catch(e){failures.push({id,title,route,format,error:e.message});console.log(`FEHLER ${format} ${id}: ${e.message}`);}
finally{await context.close();fs.writeFileSync(path.join(OUT,'manifest.json'),JSON.stringify({commit:'d4b8542821d86c7057761af16de1331d1de87e09',date:'2026-10-14',source:'Echte App-Komponenten, lokale Vorschau mit neutralisierten Beispieldaten; keine Produktivdaten',screens:manifest,failures},null,2));}
}

const recapture=new Set(['04-baustellenakte','06-planung-tag','08-schein-erfassen','09-angebote','13-wartungen','16-zeiterfassung','17-urlaub','18-mitarbeiteruebersicht','20-mitarbeiterakte','25-meine-einsaetze','26-team-woche','37-sicherung']);
for(const row of routes){if(!recapture.has(row[0]))continue;await capture(row,'desktop');await capture(row,'handy');if(tablets.has(row[0]))await capture(row,'tablet');if(darks.has(row[0]))await capture(row,'dunkel');}
for(const format of ['desktop','handy']){
await capture(['43-scheindetail','Handwerksschein Detail','/worksheets?markiert=s1',G],format);
await capture(['44-anmeldung','Anmeldung','/login',M],format);
await capture(['45-neue-baustelle','Neue Baustelle','/admin-projects',G],format,async p=>{await p.getByRole('button',{name:'Neue Baustelle',exact:true}).click();});
}
for(const format of ['handy','tablet'])await capture(['46-schein-unterschriften','Handwerksschein Unterschriften','/worksheet?entwurf=s1',M],format,async p=>{await p.getByRole('navigation',{name:'Schritte des Scheins'}).getByRole('button',{name:/Unterschrift/}).click();await p.getByLabel('Kunde (Name in Druckbuchstaben)').fill('Andrea Muster');});
await capture(['47-schein-material','Handwerksschein Material','/worksheet?entwurf=s1',M],'handy',async p=>p.getByRole('navigation',{name:'Schritte des Scheins'}).getByRole('button',{name:/Material/}).click());
await browser.close();console.log(`FERTIG ${manifest.length} Ansichten, ${failures.length} fehlgeschlagene Aufnahmen`);
