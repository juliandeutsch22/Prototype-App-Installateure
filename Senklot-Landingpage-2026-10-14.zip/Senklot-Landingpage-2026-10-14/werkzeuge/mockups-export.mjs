import {chromium} from 'playwright';
import {pathToFileURL} from 'node:url';
const out=(process.env.SENKLOT_BILDER || '/workspace/Senklot-Landingpage-2026-10-14');
const b=await chromium.launch({executablePath:(process.env.CHROMIUM_PFAD || '/usr/bin/chromium'),args:['--no-sandbox','--lang=de'],env:{...process.env,LANG:'de_AT.UTF-8',LC_ALL:'de_AT.UTF-8',LANGUAGE:'de'}});
const p=await b.newPage({viewport:{width:1920,height:1440},deviceScaleFactor:2});
for(const [id,motiv] of [['01-hero','hero'],['02-planung','planung'],['03-aussendienst','aussendienst'],['04-kaufmaennisch','kaufmaennisch'],['05-hell-dunkel','hellDunkel']]){
await p.goto('http://127.0.0.1:7199/mockups/vorlagen.html?motiv='+motiv);
await p.waitForFunction(()=>document.body.dataset.bereit==='ja');
await p.screenshot({path:out+'/mockups/'+id+'.png',omitBackground:true,animations:'disabled'});
await p.evaluate(()=>document.body.style.background='#f3f6f7');
await p.screenshot({path:out+'/mockups/'+id+'-hell.jpg',type:'jpeg',quality:92,scale:'css'});
console.log('EXPORT',id);
}
await b.close();
