# Prüfung des Bilderpakets

- 110 Aufnahmen, 47 benannte Ansichten/Zustände.
- 45 Desktop, 46 Handy, 13 Tablet, 6 dunkle Darstellung.
- 181 PNG-Dateien inklusive Gesamtseiten; 110 JPEGs für die Galerie.
- In allen Aufnahme-Kontexten kein erfasster JavaScript-Fehler; Seitenbreite innerhalb der Viewportbreite.
- Fünf Gerätemockups mit Alphakanal und transparentem Rand, jeweils 3840 × 2880 Pixel; zusätzlich helle JPEGs.
- Alle in Manifest/Galerie verlinkten Dateien vorhanden; Aufnahmeabmessungen verifiziert.
- Galerie im Browser: 110 Karten, Handyfilter 46, Suche „Wartung“ 2, Mockupbilder geladen, bei 390 px kein seitliches Überlaufen.
- Relevante Desktop-, Handy- und Mockupbilder visuell geprüft. Nicht jeder einzelne Ausschnitt wurde manuell abgenommen.
- Git-Checkout weiterhin sauber auf `main`; App-Code, Datenbank und Produktionskonfiguration unverändert.

Die Aufnahmefehler des ersten Werkzeugdurchgangs betrafen veraltete Vorschau-Stubs und ungeeignete Selektoren für responsive/dynamische Ansichten. Stubs wurden neu erzeugt; die endgültigen Aufnahmen sind erfolgreich. Der am Handy absichtlich fehlende Umschalter „Personen/Baustellen“ wurde nicht als UI-Fehler behandelt. Die native Browseranzeige von Datum/Uhrzeit wurde für die relevanten Formulare durch Starten von Chromium mit deutscher Betriebssystem-Locale korrigiert; App-Felder wurden nicht ersetzt.

Vorherige Auslieferungsprüfung: `/workspace/Auslieferungsnachweis-Senklot-2026-10-14.md`.
