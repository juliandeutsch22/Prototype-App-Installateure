# World4you: Sicherheit und Kontaktformular veröffentlichen

Stand 3. November 2026. **Diese Revision ist vorbereitet und lokal getestet; sie wurde aus dieser Sitzung nicht auf World4you hochgeladen.** Weder Hosting- noch Postfach- noch Cloudflare-Zugang sind hier eingerichtet. Die Anwendung unter app.senklot.at wurde nicht verändert.

## Was bereits enthalten ist

- Keine Analyse- oder Werbeskripte, kein allgemeines Cookiebanner und kein eigener Browser-Speicher. Schriftarten und Bilder bleiben lokal.
- Cloudflare Turnstile wird erst nach ausdrücklichem Klick mit Datenhinweis geladen. Die Einwilligung wird nicht gespeichert. Deaktivieren lädt die Seite neu; E-Mail und Telefon bleiben Alternativen. Vor der Freigabe muss die rechtliche Bewertung der konkreten Konfiguration erfolgen.
- Sicherheitsheader (CSP, Schutz vor Einbettung, nosniff, Referrer-/Permissions-Policy und HSTS über HTTPS nur für diese Domain), HTTPS-/www-Weiterleitung und gesperrte interne Verzeichnisse.
- PHP-8.2+-Kontaktbackend für World4you mit verschlüsseltem, zertifikatsgeprüftem SMTP. Kein Node-Server, Composer oder Resend-Konto auf dem Hosting erforderlich.
- Servervalidierung, feste Empfängeradresse office@senklot.at, Turnstile-Prüfung einschließlich Host/Aktion, Honeypot, Größenbegrenzung, Dateisperren für parallele PHP-Prozesse, Rate-Limit (8 Versuche pro 15 Minuten/IP-Hash) und Schutz vor wiederholtem Versand derselben Anfrage-ID (48 Stunden).
- Fehlende Konfiguration oder nicht bestätigter Versand werden nicht als Erfolg angezeigt. Eingaben bleiben bei Fehlern erhalten. Bei unklarer Zustellung wird derselbe Vorgang nicht automatisch erneut verschickt. Der Schutz bezieht sich auf dieselbe Anfrage-ID; nach Neuladen oder bei geänderten Angaben entsteht ein neuer Vorgang.
- Eigene Impressums- und Datenschutzseiten im bestehenden Design. **Sie sind aktuell sichtbar als Entwurf markiert und dürfen erst nach Vervollständigung als fertige Rechtstexte veröffentlicht werden.** Sie stehen nicht in der Sitemap und sind noindex.

## 1. Betreiberangaben und Rechtstexte vervollständigen

Im Entwicklerpaket `werkzeuge/rechtliches.json` ausfüllen:

- `name`: rechtlich vollständiger Name bzw. Firma.
- `anschrift`: vollständige ladungsfähige Postanschrift.
- `uid`, `firmenbuch`, `gewerbe`, `aufsicht`, `weitereAngaben`: soweit für Rechtsform, Tätigkeit und Offenlegung erforderlich. Kammerzugehörigkeit/Berufsregeln gegebenenfalls aufnehmen.
- `hostingDetails`: konkrete vertragliche World4you-Gesellschaft, tatsächliche Standorte, Protokollierung/Löschfristen und Auftragsverarbeitung anhand der Anbieterunterlagen bestätigen und im Text benennen.
- `turnstileDetails`: geprüfte tatsächliche Dienstkonfiguration, Empfänger, Rechtsgrundlage und Garantien für internationale Übermittlungen beschreiben. Pre-clearance ausgeschaltet lassen.

Nach inhaltlicher/rechtlicher Prüfung `freigegeben` auf `true` setzen. Dann lokal ausführen:

```
python3 werkzeuge/recht-erstellen.py
python3 werkzeuge/world4you-paket.py
```

Benötigt lokal Python mit Pillow und Node. Das neue ZIP enthält die vervollständigten Seiten. Für diesen Schritt sind keine Geheimnisse erforderlich. Alternativ können die beiden fertigen HTML-Rechtstexte fachkundig direkt bearbeitet werden; dann anschließend nicht mit den alten Platzhaltern neu generieren.

**Zusätzlicher bestehender Punkt in der App:** Die untersuchte Datei `src/features/recht/betreiber.ts` enthält ebenfalls Betreiber-Platzhalter und `GEPRUEFT=false`. Diese Angaben sind unabhängig von dieser Website-Revision zu vervollständigen. Das App-Impressum ist keine fertige Ersatzquelle.

## 2. Dateien bei World4you hochladen

1. Aktuellen Webspace einschließlich versteckter Dateien sichern.
2. PHP **8.2 oder neuer** aktivieren; die PHP-Erweiterungen **curl, openssl und ctype** müssen verfügbar sein.
3. Nur `world4you-upload.zip` entpacken und dessen Inhalt in das Web-Hauptverzeichnis von senklot.at laden. `index.html`, `.htaccess`, `api/`, `senklot-intern/`, `assets/` und die Seitenverzeichnisse liegen unmittelbar dort. Versteckte `.htaccess` und `api/.user.ini` unbedingt mit übertragen. Nicht den gesamten Entwickler-ZIP auf den öffentlichen Webspace laden.
4. Bestehende Hosting-Regeln vor dem Ersetzen mit der mitgelieferten `.htaccess` abgleichen. Erforderlich sind Apache-2.4-Regeln mit `mod_rewrite`, `mod_headers`, `AllowOverride` und `Options -Indexes`. Bei HTTP 500 den Hosting-Fehlerbericht prüfen bzw. World4you um die entsprechende Konfiguration bitten; nicht einfach den Zugriffsschutz entfernen.
5. Gültige HTTPS-Zertifikate für senklot.at und www.senklot.at sicherstellen. Die App-Subdomain wird nicht umgeleitet. HSTS enthält absichtlich weder includeSubDomains noch preload.

Das Upload-ZIP enthält geschützten Backend-Code und eine leere Beispielkonfiguration, **keine echten Zugangsdaten und keine gespeicherten Anfragen**. Bei späteren Updates ist eine bestehende `senklot-intern/config.php` nicht im ZIP und muss erhalten bleiben.

## 3. World4you-Postfach verbinden

Im World4you-Portal die **SMTP-Verbindungsdaten des tatsächlichen Postfachs** ansehen. Der Beispielhost `smtp.world4you.com` ist nur eine Vorgabe und muss mit dem Portal abgeglichen werden.

Auf dem Webspace `senklot-intern/config.example.php` zu `senklot-intern/config.php` kopieren und dort ergänzen:

- `smtp.host`: SMTP-Server aus dem Portal.
- `smtp.port` / `smtp.security`: **587 / tls** für STARTTLS oder **465 / ssl**, genau nach Anbieterangabe. Unverschlüsselter Versand ist nicht vorgesehen.
- `smtp.username`: vollständiger Postfach-Benutzername laut Portal, normalerweise office@senklot.at.
- `smtp.password`: Passwort dieses Postfachs, nicht automatisch das Kundenportal-Passwort.
- `smtp.from`: zulässiger Absender dieses Postfachs, vorgesehen office@senklot.at.

Empfänger bleibt im Backend fest office@senklot.at. Die Besucheradresse wird ausschließlich Reply-To. Passwörter niemals in Chat, E-Mail, Git oder öffentliche JavaScript-Dateien kopieren. Die PHP-Konfiguration nur über einen verschlüsselten, authentifizierten Hostingzugang bearbeiten. Berechtigungen möglichst eng setzen, beispielsweise 600 oder 640, soweit der PHP-Prozess die Datei lesen kann. `data_dir` muss nur für PHP beschreibbar sein; **kein chmod 777**. Standardmäßig legt PHP dort den Ordner `speicher` selbst an.

SPF/DKIM im World4you-Portal für den tatsächlichen Versand aktivieren/prüfen. Bestehende MX-/SPF-Einträge nicht blind ersetzen und keinen zweiten SPF-Eintrag erstellen. DMARC mit zunächst beobachtender Richtlinie kann danach anhand der vorhandenen Domainkonfiguration eingerichtet werden. Die dafür richtigen DNS-Werte müssen aus deinem Konto kommen.

## 4. Turnstile einrichten

Im Cloudflare-Konto ein **Turnstile-Widget** für `senklot.at` anlegen; falls www als zulässiger Formular-Origin verbleibt, auch diese Domain freigeben. Managed-Modus genügt. **Pre-clearance deaktiviert lassen.**

In der privaten `config.php` `turnstile.site_key` (öffentlich) und `turnstile.secret_key` (geheim) eintragen. Keine Cloudflare-Testschlüssel produktiv verwenden. Die bestehende Website muss dafür nicht pauschal auf Cloudflare-DNS umgestellt werden.

Erst wenn Angaben, Verträge, Datenschutzhinweise und Dienste fertig sind, in der privaten Konfiguration **`legal_ready => true` und `enabled => true`** setzen. Die getrennte Freigabe soll versehentliche Aktivierung verhindern; sie ersetzt keine rechtliche Prüfung.

## 5. Nach dem Upload tatsächlich prüfen

- `https://senklot.at/api/contact-config` liefert bei vollständiger Einrichtung `{mode:"live",ready:true,sitekey:"…"}`. Darin darf nur der öffentliche Widgetschlüssel stehen. Vor Freigabe ist `unavailable` korrekt.
- `https://senklot.at/senklot-intern/config.php`, `/senklot-intern/config.example.php`, `/senklot-intern/vendor/phpmailer/src/SMTP.php` und `/senklot-intern/speicher/zustand.json` müssen **403** liefern. Falls davon etwas lesbar ist, Formular nicht aktivieren und Hosting-Zugriffsschutz korrigieren.
- Browser-Netzwerkansicht: vor Klick kein Cloudflare-Aufruf. Nach Aktivierung muss der echte Turnstile-Test funktionieren; nach „Spamschutz deaktivieren und Seite neu laden“ wird Cloudflare nicht erneut geladen.
- Eine eigene Testanfrage absenden: tatsächlichen Eingang im Postfach **und Spamordner** prüfen, auf die Anfrage antworten und Reply-To kontrollieren. Erst der Postfacheingang bestätigt die reale Zustellung; eine SMTP-Annahme allein garantiert das nicht.
- Formular auf Mobilgerät und Desktop prüfen, einschließlich Fehlerfall/abgelaufener Prüfung. Keine echten Anfragen zum Testen mehrfach absenden.
- Mit `curl -I https://senklot.at/` Header prüfen: Content-Security-Policy, X-Frame-Options: DENY, X-Content-Type-Options: nosniff, Permissions-Policy, Referrer-Policy und Strict-Transport-Security. HTTPS-/www-Weiterleitung und alle sieben Marketingseiten prüfen. `/impressum/` und `/datenschutz/` dürfen nach Fertigstellung keine Platzhalter mehr enthalten.
- Hosting-/Postfach-Backups und Aufbewahrung nach tatsächlichem Vertrag prüfen, Zugänge mit 2FA schützen und Passwort-/Schlüsselwechsel sowie Updates des Versandbausteins einplanen. PHPMailer 7.1.1 ist mit konkretem Quellcommit und SHA256 in `senklot-intern/vendor/phpmailer/UPSTREAM.json` dokumentiert.

## Grenzen dieser Prüfung

Lokale Apache-/PHP-, Browser- und TLS-SMTP-Tests prüfen Implementierung und Fehlerfälle. Es wurden **keine echten E-Mails verschickt**, kein Cloudflare-Konto angelegt und keine World4you-Konfiguration geändert. Die Prüfung ist keine vollständige Penetrationsprüfung oder verbindliche rechtliche Freigabe. Ein pauschales Sicherheitsversprechen oder eine garantierte Zustellung wird nicht gegeben.

## Bestehende SEO-Einrichtung

## 2. Google Search Console

1. Unter https://search.google.com/search-console/ die Domain-Property `senklot.at` hinzufügen.
2. Den **von Google für dein Konto erzeugten** TXT-Eintrag in der DNS-Verwaltung der Domain bei World4you hinzufügen. Vorhandene Mail-/SPF-/DKIM-/MX-Einträge nicht ersetzen. Den konkreten Verifizierungscode gibt es erst im eigenen Google-Konto; im Paket ist kein erfundener Code enthalten.
3. Nach erfolgreicher Verifizierung `https://senklot.at/sitemap.xml` einreichen.
4. Mit der URL-Prüfung die Startseite und die sechs Funktionsseiten live testen und bei Bedarf die Indexierung beantragen. Anschließend den Indexierungsbericht prüfen. Ein Antrag ist keine Garantie für die Aufnahme oder Platzierung.
5. Später Suchanfragen, Klicks und tatsächlich verfügbare Core-Web-Vitals-Felddaten beobachten. Bei einer neuen Website stehen Felddaten unter Umständen noch nicht zur Verfügung.

## 3. Bing Webmaster Tools

Unter https://www.bing.com/webmasters/ anmelden und die Website nach der Google-Verifizierung aus der Search Console importieren oder eigenständig per DNS verifizieren. Dieselbe Sitemap einreichen und die URL- und Crawlingberichte prüfen. Auch dieser Schritt benötigt dein eigenes Konto.

## 4. KI-Suchen

Die Website liefert wesentliche Informationen direkt als HTML, erläutert tatsächliche Funktionen und Grenzen und besitzt intern verlinkte Funktionsseiten. `robots.txt` erlaubt öffentlichen Suchzugriff, einschließlich `OAI-SearchBot`, und sperrt nur `/api/` für Crawling. Diese Datei ist kein Zugriffsschutz.

Es wurden keine speziellen KI-Skripte, keine erfundenen Bewertungen und keine Rankingversprechen hinzugefügt. `llms.txt` ist keine Voraussetzung für Google-KI-Funktionen. Die Freigabe für Suchcrawler muss zusätzlich durch tatsächliche Hosting-/Firewall-Einstellungen respektiert werden; unbekannte Bots dürfen nicht pauschal mit einem Formular-CAPTCHA blockiert werden. Training und Suchzugriff sind unterschiedliche Steuerungen; eine zusätzliche Trainingsrichtlinie wurde hier nicht eingeführt.

## 5. URLs nach dem Upload prüfen

- https://senklot.at/
- https://senklot.at/einsatzplanung/
- https://senklot.at/zeiterfassung/
- https://senklot.at/handwerksscheine/
- https://senklot.at/kunden-baustellen/
- https://senklot.at/material-lager/
- https://senklot.at/angebote-rechnungen/
- https://senklot.at/robots.txt
- https://senklot.at/sitemap.xml

Die Funktionsseiten besitzen individuelle Titel, Beschreibungen, Canonical-URLs und Brotpfade. Die Startseite beschreibt Anbieter, Software und drei monatliche Netto-Abos als strukturierte Daten. Die Einrichtung wird gesondert erklärt. Es wird keine Eignung für besondere Rich Results behauptet.


Die sieben Marketingseiten bleiben indexierbar; die beiden Rechtstexte sind noindex. Sitemap und Suchkonten müssen nach Upload weiterhin im eigenen Konto geprüft werden.
