/* Entwurf 07: reine Darstellung mit fiktiven Daten. Keine API, keine Buchung. */
(() => {
  const variants = ['heute-a','heute-b','heute-c'];
  for (const id of variants) byId[id] = {...byId.heute,id};
  byId['monteur-c'] = {...byId['heute-monteur'],id:'monteur-c',primary:null};
  byId['rechnung-c'] = {...byId['rechnung-detail'],id:'rechnung-c',primary:null,secondary:[]};
  byId['konto-c'] = {...byId['benutzer-daten'],id:'konto-c',fields:byId['benutzer-daten'].fields.filter(f=>!['Anmeldung mit','Benutzername'].includes(f.label)).map(f=>f.label==='Rolle'?{...f,options:f.options.filter(x=>x!=='Administrator')}:f)};
  let timeMode = null;
  const recent = () => section({title:'Zuletzt geöffnet',rows:[{title:'Heizungstausch Sonnenhof',sub:'Baustelle · B-2026-0147',to:'baustelle'},{title:'RE-2026-0234',sub:'Rechnung · Hausverwaltung Sonnenhof',to:'rechnung-c'}]});
  function tasks(rows=byId.heute.rows,title='Was jetzt ansteht',extra='') {
    return '<section class="section start-actions '+extra+'"><div class="section-head"><h2>'+title+'</h2><span class="small muted">Nach Dringlichkeit</span></div>'+rows.map(r=>'<a class="dashboard-row" href="#'+r.to+'"><span class="priority '+(r.status==='Achtung'?'warning':'')+'"></span><span class="row-copy"><span class="row-title">'+esc(r.title)+'</span><span class="row-sub">'+esc(r.sub)+'</span></span><span class="row-end">'+esc(r.value)+'</span><span class="row-chevron" aria-hidden="true">›</span></a>').join('')+'</section>';
  }
  function calendar(own=false) {
    const event = (time,title,sub,next=false,to='termin') => '<a class="calendar-entry '+(next?'next':'')+'" href="#'+to+'"><span class="calendar-time">'+time+'</span><span>'+(next?'<span class="calendar-next-label"><span>Nächster Termin</span><span>in 25 Min.</span></span>':'')+'<span class="calendar-title">'+title+'</span><span class="calendar-sub">'+sub+'</span></span></a>';
    return '<section class="section start-calendar"><div class="section-head"><h2>Heute im Kalender</h2><a class="small" href="#'+(own?'mein-plan':'planung-tag')+'">'+(own?'Mein Plan':'Kalender')+'</a></div>'+(own?'':event('07:00','Heizungstausch Sonnenhof','Max und Anton · Steigleitungen',false,'planung-tag'))+'<div class="now-marker" aria-label="Beispielzeit: jetzt 10:05"><span>10:05</span><span class="now-label">Jetzt</span></div>'+event('10:30','Zwischenabnahme','Sonnenhof · Hausverwaltung',true)+(own?'':event('14:00','Besichtigung Familie Huber','Badumbau · Ringstraße 3'))+'</section>';
  }
  function team(band) {
    const arr=[['Sonnenhof','Max · Anton',2],['Neudorf','Sven · Florian · Martin',3],['Familie Huber','Daniel',1]];
    return '<section class="section team-section"><div class="section-head"><h2>Team heute</h2><span class="team-head-value">6 Personen · 3 Baustellen</span></div>'+(band?'<div class="team-track" role="img" aria-label="Eingeteilt: Sonnenhof 2, Neudorf 3, Familie Huber 1"><span style="flex:2"></span><span style="flex:3"></span><span style="flex:1"></span></div>':'')+arr.map((a,i)=>'<a class="team-row '+(!band?'no-key':'')+'" href="#planung-tag"><span class="site-label"><i class="site-key" style="background:'+['var(--brand)','var(--strong)','#b8cbd0'][i]+'"></i><span><span class="team-site">'+a[0]+'</span><span class="team-people">'+a[1]+'</span></span></span><strong>'+a[2]+'</strong></a>').join('')+'</section>';
  }
  function start(id) {
    const c=id==='heute-c', b=id!=='heute-a';
    return head(current)+metrics(c?byId.heute.metrics.slice(0,2):byId.heute.metrics)+'<div class="start-layout">'+(c?'<div class="s-tasks">'+tasks()+'</div><div class="s-calendar">'+calendar()+'</div><div class="s-team">'+team(b)+'</div><div class="s-recent">'+recent()+'</div>':'<div class="s-main">'+tasks()+recent()+'</div><aside class="s-side">'+calendar()+team(b)+'</aside>')+'</div>';
  }
  function worker() {
    return head(current)+'<div class="worker-layout"><div><section class="job-summary"><p class="eyebrow">Dein Einsatz heute</p><h2>Heizungstausch Sonnenhof</h2><p class="job-meta">B-2026-0147 · geplant 07:00–15:30</p><p class="crew-today">Heute mit Anton Berger</p><div class="job-contact"><a href="https://www.openstreetmap.org/search?query=Hauptstra%C3%9Fe%20112%2C%202700%20Wiener%20Neustadt" target="_blank" rel="noopener"><span>Adresse</span><span>Hauptstraße 112 · 2700 Wiener Neustadt</span></a><a href="tel:+43262212345"><span>Kontakt</span><span>Andrea Muster · 02622 12345</span></a></div><p class="job-task">Steigleitungen in Stiege 2 fertigstellen und Heizkörper im 1. OG montieren.</p><div class="job-buttons"><button type="button" class="btn primary" data-time-mode="last">Wie zuletzt buchen<small>07:00–15:30 · 30 Min. Pause · 8:00 h</small></button><button type="button" class="btn" data-time-mode="empty">Andere Zeit</button></div><div class="job-inline-actions"><a href="#schein-zeiten">Schein schreiben</a><a href="#mein-plan">Mein Einsatzplan</a></div></section><section class="section"><h3 class="ruest-title">Material mitnehmen</h3>'+[['Pressfitting 22 mm','8 Stk.'],['Thermostatventil','2 Stk.'],['Verbundrohr 20 mm','20 m']].map(a=>'<label class="ruest-check"><input type="checkbox"><span>'+a[0]+'</span><span class="qty">'+a[1]+'</span></label>').join('')+'</section></div><aside class="worker-side">'+calendar(true)+tasks(byId['heute-monteur'].rows.slice(1),'Noch offen','worker-pending')+'</aside></div>';
  }
  function invoice() {
    return head({...current,title:'Rechnung RE-2026-0234',subtitle:'Hausverwaltung Sonnenhof',secondary:[{label:'Mahnung prüfen',to:'mahnen'},{label:'Stornieren',to:'rechnung-storno'}]})+'<div class="receipt-layout"><section><h2 class="receipt-title">Heizungstausch Sonnenhof</h2><p class="receipt-sub">Schlussrechnung · B-2026-0147</p><p class="receipt-amount-label">Offener Betrag</p><p class="receipt-amount">€ 4.860,00</p><p><span class="status warning">14 Tage überfällig</span></p><div class="receipt-actions"><a class="btn primary" href="#zahlung">Zahlung erfassen</a><button class="btn text" data-demo="PDF laden">PDF laden</button></div>'+section(current.sections[0])+'</section><aside class="receipt-side receipt-events">'+section({title:'Zahlungen',text:'Noch keine Zahlung zugeordnet.',rows:[]})+section({title:'Mahnverlauf',text:'Noch keine Mahnung erzeugt.',rows:[{title:'Mahnung prüfen',sub:'Voraussetzungen und nächste Stufe prüfen',to:'mahnen'}]})+'</aside></div>';
  }
  function apply() {
    const id=current.id;
    document.body.classList.toggle('variant-c',id==='heute-c');
    const label=$('.top-label');if(label)label.textContent='Lot v2 · Entwurf 07';
    if(variants.includes(id))$('#main').innerHTML=start(id);
    else if(id==='monteur-c')$('#main').innerHTML=worker();
    else if(id==='rechnung-c')$('#main').innerHTML=invoice();
    else if(id==='konto-c'){
      const form=$('#concept-form')||$('.form');
      if(form)form.insertAdjacentHTML('afterbegin','<div class="identity-fact"><p class="row-sub">Anmeldung mit Benutzername</p><p class="row-title">max.mustermann</p><p>Das Anmeldekonto wird getrennt von den Stammdaten geändert.</p><a href="#konto-umstellen">Anmeldeart umstellen</a></div>');
    }
    if(['heute-a','heute-b','heute-c','monteur-c','rechnung-c'].includes(id))$('#main').insertAdjacentHTML('beforeend','<p class="prototype-note">Gestaltungsentwurf · fiktive Beispieldaten · Beispielzeit 14.10.2026, 10:05</p>');
    if(id==='zeit'&&timeMode){
      [['Von',timeMode==='last'?'07:00':''],['Bis',timeMode==='last'?'15:30':''],['Pause (Min.)',timeMode==='last'?'30':'']].forEach(([k,v])=>{const input=document.querySelector('[data-field="'+k+'"] input');if(input){input.value=v;input.dispatchEvent(new Event('input',{bubbles:true}));}});
      timeMode=null;
    }
  }
  document.addEventListener('click',e=>{const btn=e.target.closest('[data-time-mode]');if(btn){timeMode=btn.dataset.timeMode;location.hash='zeit';}});
  window.addEventListener('hashchange',apply);
  if(!location.hash)location.hash='heute-c';else{render();apply();}
})();
