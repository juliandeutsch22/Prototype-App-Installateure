# Senklot – Bilder für die Landingpage

Stand 14.10.2026, App-Commit `d4b8542821d86c7057761af16de1331d1de87e09`.

**110 Bildschirmaufnahmen aus 47 Ansichten und Zuständen**, aufgenommen mit den echten React-Komponenten des ausgelieferten App-Stands. Dazu fünf fertige Gerätemockups. Die Datenschicht ist die lokale Vorschau, mit einem für die Bilder zusammengestellten fiktiven Bestand. Keine Produktion wurde angemeldet, beschrieben oder bereinigt. UI-Elemente wurden weder versteckt noch grafisch ersetzt. Die zusätzlichen Browser-/Geräterahmen gehören ausschließlich zu den Mockups.

## Verwenden

1. ZIP vollständig entpacken, dann `index.html` öffnen. Die Galerie funktioniert ohne Internet.
2. Nach Desktop, Handy, Tablet oder Dunkel filtern und eine Ansicht wählen. „PNG in 2×“ lädt den sichtbaren Ausschnitt; „Ganze Seite“ die vollständige Ansicht.
3. Für die Landingpage bevorzugt die transparenten PNGs aus `mockups/` verwenden. Für einen hellen Hintergrund gibt es dieselben Motive als kleinere JPEGs.

## Fertige Mockups

- `mockups/01-hero.png`: Einsatzplanung am Desktop, Zeiterfassung am Handy. Empfohlen für den ersten großen Bildbereich.
- `mockups/02-planung.png`: Monatsplanung und die eigenen Einsätze am Handy.
- `mockups/03-aussendienst.png`: Zeiterfassung, Handwerksschein und Materialanforderung auf drei Handys.
- `mockups/04-kaufmaennisch.png`: Angebot am Desktop, Rechnungen am Handy.
- `mockups/05-hell-dunkel.png`: Planung in dunkler Desktop-Darstellung mit heller Tablet-Ansicht.

Alle fünf PNGs sind **3840 × 2880 Pixel mit transparentem Hintergrund**. JPEGs `*-hell.jpg` sind 1920 × 1440 Pixel. Die HTML-Vorlage `mockups/vorlagen.html` bleibt editierbar; die Ansicht wird über `?motiv=hero`, `planung`, `aussendienst`, `kaufmaennisch` oder `hellDunkel` gewählt.

## Umfang und Auflösung

- 45 Desktop-Aufnahmen, 46 Handy-Aufnahmen, 13 Tablet-Aufnahmen, 6 dunkle Desktop-Aufnahmen.
- Desktop: 1440 × 1000 CSS-Pixel, PNG 2880 × 2000.
- Handy: 390 × 844 CSS-Pixel, PNG 780 × 1688.
- Tablet: 834 × 1112 CSS-Pixel, PNG 1668 × 2224.
- Gesamtseiten sind entsprechend höher. JPEGs unter `vorschau/` dienen der schnellen Galerie; für Layout/Export die PNGs verwenden.

Erfasst sind Startseiten für Büro und Monteur, Baustellen und Akte, Tages-/Wochen-/Monatsplanung, Planung nach Baustellen, Scheine einschließlich Detail/Entwurf/Material/Unterschriften, Angebote und Akte, Kunden und Akte, Wartungen, Rechnungen und Detail, Nachkalkulation, Zeiterfassung, Urlaub/Freistellungen, Mitarbeiterübersicht, Benutzerverwaltung und Mitarbeiterakte, Materialanforderung/Verwaltung/Lager, eigene Baustellen und Einsätze, Teamwoche, alle elf Einstellungsunterseiten, Anmeldung, neues Baustellenformular sowie Impressum und Datenschutz.

Plattformadministration, Zwei-Faktor-Geheimnisse, Wiederherstellungscodes, jeder einzelne Dialog und alle Rollenvarianten sind nicht Teil dieses Marketingpakets. Die Bilder zeigen echte vorhandene Ansichten, keine frei erfundenen Zusatzfunktionen. „Impressum/Datenschutz“ zeigen die vorhandenen Entwürfe und sind nicht als fertige Rechtstexte für eine Landingpage gedacht.

## Beispieldaten

„Mustertechnik Installationen GmbH“, „Hausverwaltung Sonnenhof“, Personen, Beträge und Laufzustände sind Demoangaben. Adressen für E-Mail/Web wurden auf reservierte `.example`-Domains geändert. Ein grüner Sicherungsstatus in der Vorschau bestätigt keine produktive Sicherung. `demo-daten.js` dokumentiert die Anpassungen des Vorschau-Bestands. Zahlen/Salden sind als Abbild dieses Demo-Bestands zu lesen, nicht als Prüfung echter Geschäftsdaten.

## Kontrolle

Alle 110 Aufnahmen renderten ohne erfassten JavaScript-Fehler und ohne seitliches Überlaufen der Seite. Relevante Bilder wurden visuell durchgesehen. Auflösung, Bilddateien, Transparenz, Galerie-Verweise und Filter wurden separat kontrolliert. Das ersetzt keine Geräte- oder fachliche Abnahme. Die App und der saubere `main`-Checkout wurden nicht geändert.

`manifest.json` enthält je Aufnahme die Route, Rolle, Breite, Auflösung, Überschriften und Bildpfade. `Offene-technische-Punkte.md` benennt den tatsächlichen technischen Rest. Reproduktionsskripte liegen unter `werkzeuge/`; für ihre Ausführung wird der Repository-Checkout mit installiertem Playwright und laufender lokaler Vorschau benötigt.
